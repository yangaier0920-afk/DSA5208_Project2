# Singapore rainfall patterns and 30-minute exceedance prediction

DSA5208 Project 2 | 2017-2024 | 12 October 2026

## Group members

- SHAO YUQING - Student ID: A0330603W

- YANG AIER - Student ID: A0354958J

- ZHU YIXU - Student ID: A0355117H

## 1. Introduction and main findings

This project uses the eight annual Singapore rainfall datasets from 2017 to 2024 to address two tasks: describe within-year and interannual rainfall patterns, and estimate the probability that a station will accumulate more than an input threshold during the next 30 minutes. Apache Spark performs structured processing and feature computation; Spark MLlib trains and evaluates the probability models. All times use Asia/Singapore.

## 2. Data provenance and cleaning

The source is NEA's Historical Rainfall across Singapore collection on data.gov.sg [1]. It provides station measurements and timestamps in Singapore Time; its notice states that records may be missing and do not have the quality-control status of official climate data. The project uses 2017-2024, not the collection's additional 2016 file. Raw exports occupy 8,047,044,701 bytes. Annual titles, dataset URLs and locally computed whole-file SHA-256 hashes are recorded in manifests/raw_manifest.json. Download completeness was confirmed in the original project; the local hashes are not server-issued checksums.

We retain the original 12 text columns, original record, source-file identity, hashes and event timestamp. Structural, rainfall-number, unit/type and original-key checks found no violations in this release. Only 2017 records with epoch remainder 299 modulo 300 are shifted forward by one second to an aligned five-minute endpoint. This affects 1,775,327 source rows. Original timestamps and alignment flags remain available for traceability.

Alignment creates 86 equal-rainfall key-collision pairs. We keep the original exact-grid row, neither summing nor averaging rainfall, and preserve both records in 172 lineage rows. Two retained observations have metadata-conflict flags. Unequal-rainfall collisions would be quarantined as entire groups; none occur. Finite nonnegative measurements, genuine zero values and extremes are retained without arbitrary clipping or rounding to 0.2 mm. Missing timestamps remain unknown; no zero rows are synthesized.

The count reconciliation is 48,538,713 = 48,538,627 observations + 86 merged removals + 0 quarantined. There are 47,121,647 genuine zero-rainfall observations. Zero quarantined rows establish the implemented ledger, not meteorological quality or temporal completeness. The raw event-date audit identifies 63 days with no network observations, including 4-31 August 2018. Their physical cause cannot be inferred from these files.

| Year | Raw rows | Retained | Future complete | History complete | Both complete |
|---|---|---|---|---|---|
| 2017 | 5,256,106 | 5,256,020 | 5,057,559 | 4,941,980 | 4,822,618 |
| 2018 | 4,594,246 | 4,594,246 | 4,079,741 | 4,028,323 | 3,981,287 |
| 2019 | 5,026,862 | 5,026,862 | 4,991,346 | 4,965,109 | 4,935,783 |
| 2020 | 6,334,473 | 6,334,473 | 6,292,286 | 6,264,593 | 6,234,155 |
| 2021 | 7,044,646 | 7,044,646 | 7,013,455 | 6,995,148 | 6,976,422 |
| 2022 | 7,133,230 | 7,133,230 | 7,108,318 | 7,091,648 | 7,073,178 |
| 2023 | 6,742,890 | 6,742,890 | 6,719,652 | 6,704,161 | 6,687,003 |
| 2024 | 6,406,260 | 6,406,260 | 6,374,476 | 6,356,871 | 6,338,426 |

Table 1. Annual cleaning and window counts. Retained rows sum to 48,538,627. All anchors are preserved in the targets table, including invalid-window anchors; window exclusion is a downstream supervision rule, not cleaning deletion.

## 3. Time contract, truth and missingness

Let R(t) denote rainfall in the five-minute interval (t-5 min, t], with t the aligned endpoint. This interval meaning and the availability of R(t) at t are explicit project assumptions; they are not independently established official semantics or verified real-time publication behaviour. Calendar summaries use rain_period_start_ts = t-300 s, so a midnight-ending interval belongs to the preceding date.

The future truth is S(t) = R(t+300) + R(t+600) + ... + R(t+1800), covering (t,t+30 min] and excluding R(t). All six exact endpoints must exist. The most recent hour uses the 12 exact endpoints t-3300,...,t, covering (t-60 min,t]. Adjacent-year context is loaded before anchor selection. Row offsets cannot replace exact timestamps when records are missing.

| Component | Exact endpoint offsets from t | Policy |
|---|---|---|
| History | -3300,-3000,...,-300,0 seconds | All 12 positions required |
| Future | 300,600,900,1200,1500,1800 seconds | All 6 positions required |
| Label | S(t) > input threshold (mm) | Equality is negative; unknown is not negative |

Future totals and threshold comparisons use Decimal(38,18). Source precision required at most five effective decimal places; storage scale does not imply measurement precision. There are 47,636,833 complete future windows and 901,794 unknown future totals; 47,347,833 complete histories and 1,190,794 incomplete histories. Both are complete at 47,048,872 anchors. These exclusions overlap and must not be added as disjoint losses.

Training/validation/test role fields purge the actual temporal boundary, including label endpoints equal to the next block's start. Internal year boundaries within the training block may be used when context is complete. Inference checks only station support and past-history completeness; future truth, model_anchor_eligible and role never determine whether a real-time request is accepted.

## 4. Task 1: coverage determines valid comparisons

Station-month observed rainfall sums and wet-slot fractions are computed by Spark and checked against A's interval-calendar coverage reference for 6,528 station-month entries. A month qualifies at >=90% observed calendar slots; >=95% is a prespecified sensitivity rule. Within-year descriptive summaries weight qualified stations equally, then available year-months equally where appropriate. Sums are not scaled to fill missing rainfall.

![Figure 1. Qualified station counts and fixed eight-year same-month panels.](assets/task1_01_coverage_and_panel.png)

Figure 1. Qualified station counts and fixed eight-year same-month panels.

## 4.1 Annual summaries and the limits of coverage

| Year | Annual >=90% stations | Observed mean (mm) | Every month >=90% stations |
|---|---|---|---|
| 2017 | 40 | 2364.9 | 9 |
| 2018 | 0 | NA | 0 |
| 2019 | 41 | 1667.9 | 0 |
| 2020 | 42 | 2572.0 | 0 |
| 2021 | 66 | 2818.1 | 0 |
| 2022 | 66 | 2898.9 | 54 |
| 2023 | 59 | 2745.9 | 0 |
| 2024 | 56 | 2658.1 | 29 |

![Figure 2. Annual descriptions at 90%/95% annual coverage and the stricter every-month rule.](assets/task1_06_annual_descriptive_summary.png)

Figure 2. Annual descriptions at 90%/95% annual coverage and the stricter every-month rule.

2018 has no station meeting 90% annual coverage and is kept as NA. The eight-year fixed annual station intersection is empty. Descriptive means range from approximately 1,667.9 mm in 2019 to 2,898.9 mm in 2022 among each year's qualifying stations, but these are observed totals from changing station sets. They are not comparable estimates of national annual totals, nor evidence of a long-term climate trend. Requiring every month to pass coverage eliminates the entire annual panel in several years, demonstrating why an annual average coverage rule can hide concentrated missingness.

## 4.2 Within-year seasonality: frequency differs from intensity

![Figure 3. Descriptive station-mean monthly observed rainfall; NA means unsupported coverage.](assets/task1_02_descriptive_monthly_rainfall.png)

Figure 3. Descriptive station-mean monthly observed rainfall; NA means unsupported coverage.

The largest descriptive year-month cell is October 2022: 419.1 mm across 66 qualifying stations. The smallest is February 2021: 32.0 mm across 68 stations. Month lengths, actual weather, coverage and station composition all contribute to these differences; they are not fixed-network cross-year rankings.

![Figure 4. Observed wet-slot frequency and conditional nonzero rainfall intensity.](assets/task1_07_frequency_and_intensity.png)

Figure 4. Observed wet-slot frequency and conditional nonzero rainfall intensity.

At the 90% rule, November has the highest descriptive wet-slot fraction (4.30%), while March has the highest mean station-month nonzero five-minute P90 (2.84 mm). Thus rain occurrence and conditional intensity need not peak in the same month. Spark percentile_approx uses accuracy=1000; station-month nonzero quantiles are averaged across qualified stations and available years. They are not quantiles of all pooled national observations. All-dry groups have wet frequency zero but unknown conditional intensity, not a zero-filled intensity.

## 4.3 Interannual comparisons on fixed same-month stations

![Figure 5. Fixed eight-year same-month panels; 90% versus 95% coverage.](assets/task1_03_strict_interannual_comparison.png)

Figure 5. Fixed eight-year same-month panels; 90% versus 95% coverage.

| Month | Stations 90%/95% | Lowest year | Highest year | Largest mean difference (mm) |
|---|---|---|---|---|
| 5 | 11/9 | 2023/2023 | 2024/2024 | 9.92 |
| 9 | 20/17 | 2019/2019 | 2020/2020 | 4.90 |
| 10 | 21/18 | 2023/2023 | 2022/2022 | 5.32 |
| 12 | 18/15 | 2021/2021 | 2023/2023 | 8.00 |

Only May, September, October and December have supported eight-year panels. The lowest/highest years agree at both coverage cutoffs for each supported month. For October's 21-station 90% panel, the 2022 mean is 399.8 mm and the 2023 mean is 113.0 mm. May peaks in 2024, September in 2020, October in 2022 and December in 2023; no single year is wettest everywhere. Adding these four months would not create an annual comparison. The 95% cutoff changes composition and means, so stable extrema are sensitivity evidence rather than a significance test.

Across 12 descriptive months, changing the rule to 95% leaves the peak occurrence month November and peak P90 month March unchanged; the maximum difference in mean wet-slot fraction is 0.0528 percentage points. This quantifies stability of the descriptive definition, not independence or causality.

## 4.4 Diurnal patterns and station heterogeneity

![Figure 6. Singapore-time wet-slot occurrence by month/hour and daily profile.](assets/task1_04_hourly_rain_occurrence.png)

Figure 6. Singapore-time wet-slot occurrence by month/hour and daily profile.

The hourly panel requires every hour of a station-month to meet 90% coverage, ensuring the same station composition throughout its daily curve. Station means are then averaged across 82 supported year-months. Wet-slot occurrence peaks at 16:00 (5.78%) and is lowest at 23:00 (1.11%). This is the frequency of observed five-minute rain slots, not a forecast probability of exceeding a future 30-minute threshold or evidence of a physical mechanism.

![Figure 7. Station contrasts in October, the largest supported fixed same-month panel.](assets/task1_05_station_comparison.png)

Figure 7. Station contrasts in October, the largest supported fixed same-month panel.

October is selected by the largest 90% eight-year panel (21 stations), breaking ties toward the earliest month. S89 averages about 270.3 mm and S107 about 125.2 mm. This is an October contrast, not an annual station ranking or a location-adjusted causal result. The interval-start calendar has 64 entirely missing network dates versus 63 in the event-date audit; the additional 2018-02-17 reflects calendar definition. Missing dates are not dry dates.

## 5. Task 2: causal feature construction and model inputs

We retain all 48,538,627 B feature anchors. Of these, 47,347,833 (97.547%) have complete 60-minute history, with only 87.682% completeness in 2018. Windows and exact lags use epoch-key positions with cross-year context; missing slots stay null. Supervised samples also require complete future truth and safe temporal roles, so history retention is not final modelling retention.

| Feature group | Numeric inputs and purpose |
|---|---|
| Recent level and exact lags | Current 5-minute rainfall; lags 5/10/15/30 minutes; capture short-term persistence. |
| Window totals and changes | 15/30/60-minute totals, previous 15-minute total, changes over 5/15 minutes, 15/30 ratio. |
| Window variability | 60-minute maximum, population standard deviation and wet-slot count. |
| Wetness and persistence | Current/lag5/lag10 wet indicators; trailing wet run and its left-censor flag. |
| Recency | Minutes since last observed wet slot capped at 60 plus no-wet-observed flag. |
| Calendar | Hour sine/cosine and month sine/cosine. |
| Additional inputs | Numeric rainfall threshold; station category fitted with training-only StringIndexer/OneHotEncoder. |

These groups total 26 B numeric columns. All-dry complete 30-minute windows have ratio zero; incomplete windows have null. An all-wet hour gives run length 12 and a left-censor flag; the true rain-run start may precede the window. No observed wet slot within a complete hour gives recency code 60 plus a censor flag, not a known true 60-minute gap. Full definitions are delivered in B_delivery/docs/FEATURE_DEFINITIONS.md and its CSV. No future rainfall, future completeness, eligibility, role or whole target record enters the feature vector.

Features were specified from historical rainfall, persistence and periodic time structure. We compare complete model families using the same feature set; there is no old-versus-new feature ablation, so we do not claim that the additional B_v2 columns independently improve performance. With complete input history, no imputation is fitted. Logistic regression uses internal training-only standardization; tree splits do not require scaling. Station categories are fitted independently inside each sampled training fold.

| Final tree feature | Normalized impurity importance |
|---|---|
| rain_sum_15m_mm | 0.616424 |
| threshold_mm | 0.212747 |
| current_5m_mm | 0.108971 |
| rain_sum_30m_mm | 0.048103 |
| minutes_since_last_rain_60m_capped | 0.006784 |
| consecutive_wet_slots_60m | 0.004353 |
| rain_change_15m_mm | 0.002619 |

The final shallow tree splits on seven inputs. The 15-minute rainfall sum, threshold and current five-minute rainfall account for about 93.8% of its normalized impurity importance. Station and periodic-calendar inputs are accepted but are not used by this fitted tree's splits. Prediction time still determines the exact historical anchor and features, and station selects its series. Training impurity importance is neither causal attribution nor independent feature-selection evidence.

## 6. E2 temporal validation and prespecified selection

We use explicit expanding temporal windows, not Spark's ordinary random-fold CrossValidator: train 2017-2020/validate 2021, train 2017-2021/validate 2022, and train 2017-2022/validate 2023. After selection, refit 2017-2023 and test 2024 once. Threshold support is determined only from the earliest full eligible training block (19,973,411 anchors), requiring at least 100 positives and negatives per threshold. All five candidates 0,0.5,1,2,5 mm pass; at 5 mm there are 149,425 positives.

A 1% deterministic anchor sample first checks implementation, not selection. Formal training uses a fixed 10% hash sample, seed=20261012, with pmod(xxhash64(station_id,prediction_epoch_s,seed),10000)<1000. Sample anchors before threshold expansion and keep all five versions together. Sampling is not label-dependent; there is no class balancing or weighting. Validation/test score all eligible anchors from training-supported stations. These runs exclude no evaluation anchors for unknown stations; the deployed interface still rejects an unseen station.

| Candidate | Fixed specification |
|---|---|
| Frequency baseline | Separate exceedance prevalence for each threshold, estimated only from sampled training anchors. |
| Logistic regression | Spark MLlib; L2 regParam=0.01, elasticNet=0, maxIter=40, tol=1e-6, internal standardization. |
| Decision tree | Spark MLlib; maxDepth=5, maxBins=32, minInstancesPerNode=100 expanded rows, fixed seed. |

The main criterion averages Brier across the five frozen thresholds within each validation year, then weights the three years equally. A predeclared absolute tie tolerance of 1e-5 favors baseline, then LR, then tree. Probability postprocessing and calibration are not tuned on 2024. The selected configuration is saved in selection.json at 2026-10-12 17:19:21 SGT, before final refit/test execution.

| Stage | Sampled train anchors | Full evaluation anchors | Observed-anchor coverage |
|---|---|---|---|
| fold1 | 1,995,803 | 6,976,044 | 99.026% |
| fold2 | 2,693,419 | 7,072,758 | 99.152% |
| fold3 | 3,401,643 | 6,686,625 | 99.166% |
| final | 4,071,679 | 6,338,426 | 98.941% |

Coverage is relative to all observed anchors in the evaluation year, not an ideal complete station-calendar grid. Actual filtered/sampled inputs are audited before threshold expansion for unique/null keys, full left matching and zero row inflation. Afterwards the station/time/threshold key is unique, every anchor has five thresholds and labels are nonnull. All four actual-input and expansion audits pass.

## 6.1 Development results and the metric trade-off

| Model | 2021 Brier | 2022 Brier | 2023 Brier | Equal-year mean |
|---|---|---|---|---|
| frequency_baseline | 0.028542 | 0.029113 | 0.029928 | 0.029194 |
| logistic_regression | 0.017683 | 0.018778 | 0.019041 | 0.018501 |
| decision_tree | 0.016875 | 0.017773 | 0.018108 | 0.017585 |

![Figure 8. Equal-threshold rolling-validation Brier scores.](assets/model_01_rolling_brier.png)

Figure 8. Equal-threshold rolling-validation Brier scores.

Both learned models outperform the frequency baseline in all three validation years. The decision tree is best in each year's mean Brier, with a three-year score 0.017585 and a year range 0.001233. This improvement is consistent in these three years, but no independent-sample confidence intervals are reported because windows overlap and stations share weather.

The tree is not best under every diagnostic. For the 2023 >2 mm task, LR has PR-AUC 0.481283 and ROC-AUC 0.900575 versus the tree's 0.429597 and 0.831717, while the tree has better Brier (0.011994 versus 0.012636). AUC evaluates ranking; Brier evaluates probability squared error. We retain this trade-off and choose the tree under the protocol specified before scoring, rather than switching to a favorable metric. A single shallow-tree configuration and one LR setting are a limited initial comparison, not an exhaustive search.

## 7. Locked 2024 final test

The final tree is refitted on 4,071,679 sampled 2017-2023 anchors, expanding to 20,358,395 training rows. Station encoding is refitted on this training block. The 2024 test has 6,338,426 eligible anchors, or 31,692,130 threshold-expanded rows, with observed-anchor coverage 98.941%. The frequency reference is refitted from the same final training sample. No LR is newly evaluated on 2024 and no test-driven candidate selection is performed.

| Threshold mm | Event rate | Baseline Brier | Tree Brier | Skill % | Log loss | PR-AUC | ROC-AUC |
|---|---|---|---|---|---|---|---|
| 0 | 6.361% | 0.059571 | 0.034183 | 42.62 | 0.150547 | 0.681425 | 0.805980 |
| 0.5 | 3.627% | 0.034960 | 0.020544 | 41.24 | 0.090920 | 0.610258 | 0.839476 |
| 1 | 2.571% | 0.025050 | 0.015685 | 37.38 | 0.070748 | 0.550593 | 0.839012 |
| 2 | 1.684% | 0.016555 | 0.011781 | 28.83 | 0.055588 | 0.438596 | 0.831617 |
| 5 | 0.835% | 0.008279 | 0.006486 | 21.66 | 0.036065 | 0.357150 | 0.831203 |

![Figure 9. Final-test probability error and relative skill by frozen threshold.](assets/model_02_final_brier.png)

Figure 9. Final-test probability error and relative skill by frozen threshold.

The five-threshold mean Brier is 0.017736 versus 0.028883 for the frequency baseline (38.59% improvement). Improvements range from 42.62% at >0 mm to 21.66% at >5 mm. The >5 mm event occurs at only 0.835% of test anchors; its PR-AUC is 0.357150, substantially above prevalence, but rare-event performance is weaker than at lower thresholds. A smaller raw Brier at high thresholds does not by itself mean a more useful or easier task.

Brier is mean (p-y)^2; log loss is mean -y log p -(1-y) log(1-p), with probability clipped to [1e-15,1-1e-15] only for numeric stability in that metric. Stored probabilities remain unchanged. ROC-AUC and PR-AUC use Spark BinaryClassificationEvaluator with numBins=1000 (approximate curve integration); a single-class group would be NA. Accuracy is not used as the primary measure for rare events.

## 7.1 Reliability, threshold behaviour and inference

![Figure 10. Final tree reliability curves at fixed bins; bin counts are unequal.](assets/model_03_final_reliability.png)

Figure 10. Final tree reliability curves at fixed bins; bin counts are unequal.

Fixed bins compare mean predicted probability with observed event frequency; bin counts and probabilities are preserved in final/decision_tree_calibration.csv. The plot is a diagnostic, not a test-set calibration procedure. The fitted tree has zero adjacent-threshold probability increases in this test: predicted probabilities do not rise when the threshold increases at the same anchor. No monotonic postprocessing is applied, and this empirical check is not a guarantee for all possible future inputs.

The final artifact stores the whole fitted station encoder, assembler and classifier, plus the discrete threshold/station/history contract. A fresh Spark process reloads it and compares 100 deterministic test anchors / 500 threshold probabilities against saved scoring: maximum absolute difference is 0. The single-anchor API receives only the station's observations ending at or before t and reproduces all five probabilities. Missing history, off-grid time, unknown station and an unsupported threshold are correctly rejected.

The API takes station_id, prediction_epoch_s and threshold_mm and returns a probability of the strict future event. It uses all 12 exact historical slots, including R(t) under the project availability assumption. Threshold support is deliberately restricted to 0,0.5,1,2,5 mm; arbitrary continuous thresholds are not claimed to be evaluated. If actual publication latency makes R(t) unavailable, the availability cutoff, features and evaluation must be redesigned rather than deploying these numbers unchanged.

## 8. Computing environment and reproducibility

The original eight-year A audit/cleaning/target runs were on Windows 11 with an Intel Core i7-12700H (14 physical/20 logical cores), about 31.73 GiB visible memory, Python 3.11.5, PySpark 3.5.7 and Java 17.0.20.1. Local[4], 4g driver heap and 48 shuffle partitions are single-machine threads, not four cluster nodes. Lifecycle wall times are 31.48,34.27,9.82 minutes for audit, cleaning and targets; these are preserved original receipts, not claimed new Mac full raw runs.

The current replay/B/C execution uses an Apple M3 Max (14 logical CPUs), 36 GB memory and macOS 14.1, Python 3.11.17, PySpark 3.5.7, Py4J 0.10.9.7 and Java 17.0.20.1. B uses local[2],4g heap,128 shuffle partitions; C uses local[2],6g heap,128 partitions. Both cap input partitions at 32 MiB, enable AQE and disable adaptive partition coalescing. C persists projected training vectors with DISK_ONLY; neither B nor C caches complete observations. Heap is a configuration, not peak RSS; peak resources were not instrumented.

## 8.1 Measured runtime and functional checks

| Stage | Seconds | Timing scope |
|---|---|---|
| B Task 1 | 38.3 | Integrity/startup through aggregate CSV writes; excludes later charts and shutdown |
| B features | 152.8 | Integrity, reading, computation, write/read checks and 513 probes; excludes output hashes/shutdown |
| fold1 | 346.4 | Actual joins, materialization, expansion checks, fitting, full scoring and metrics |
| fold2 | 383.9 | Actual joins, materialization, expansion checks, fitting, full scoring and metrics |
| fold3 | 412.3 | Actual joins, materialization, expansion checks, fitting, full scoring and metrics |
| final | 312.1 | Actual joins, materialization, expansion checks, fitting, full scoring and metrics |

C fold timing excludes each stage's preceding file-hash check and Spark startup, subsequent report plotting and fresh-process packaging/reload. Candidate fit_seconds records classifier fitting only, excluding shared preprocessing and earlier frequency estimation. These are single local measurements with uncontrolled filesystem cache, not stable performance benchmarks. Formal A Parquet payload is 4,678,105,303 bytes; this is not peak disk demand.

The current Mac verifies both full tables at 48,538,627 rows and confirms one-to-one unique keys and null-future semantics. A's original target checks independently recompute 29 real cases / 522 expected positions. The current frozen-production replay uses 1,297 preserved raw fragments, all 86 collision pairs and 114 selected anchors; observations, lineage and targets match reference rows and Decimal oracles. It takes about 15 seconds on local[2]/2g/8 partitions and is a functionality check, not full-scale performance.

B verifies 513 independent real timestamp probes, six synthetic feature edge cases and all 26 offline/online feature columns. A/B full-table joining has 100% matching, no duplicates and no inflation; C additionally audits its actual post-filter/post-sample training and evaluation inputs. Strict Decimal tests include equality and values exceeding a threshold by 10^-18, and hashing tests confirm order-independent nested samples. Model reloading and past-only inference checks complete the delivered end-to-end chain.

Current README and reader differ from frozen release hashes. A portable helper builds an isolated runtime with the matching historical README/reader bytes while retaining current source. Data and frozen algorithms are not changed. The current resource-adjusted reader (2 threads/256 partitions) passed full verification after the old resource settings exhausted aggregation memory. The submission preserves hashes, original evidence and runtime preparation instructions rather than silently relaxing integrity checks.

## 9. Limitations and further work

Missing observations affect descriptive support and evaluation population; an empty common panel or NA annual total is not zero rainfall. Station composition, potential relocation/measurement differences, extreme readings and unverified publication latency remain limitations. Neither coverage sensitivity nor zero quarantine establishes official climate quality. Eight years support descriptive comparisons, not long-run climate or causal attribution.

Forecast evaluation is conditional on complete past/future supervision, safe boundaries and trained station support. Overlapping 30-minute labels and nearby stations induce dependence; no independent-row significance claims or confidence intervals are made. Ten-percent anchor sampling is unbiased with respect to the observed keys but does not fix observational missingness. No full-training ablation, broader tree-ensemble search, feature ablation, external-weather integration or live latency reconstruction is performed. Those are defensible future experiments to develop on new validation data; 2024 must not be repeatedly reused as an untouched test.

## 10. AI usage declaration and conclusions

OpenAI Codex assisted across A/B/C with planning, code and documentation, data-quality and reproduction workflows, feature and model implementation, experiment execution, visualizations, integrity checks and report drafting/integration. Reported counts and predictive metrics are obtained from actual saved Spark outputs. Synthetic tests are identified as synthetic and are not presented as full-data findings. Automated checks do not imply that group members have independently reviewed every source line. The named submitting members should review the implementation, assumptions and this disclosure before submission and add any additional AI tools actually used.

Task 1 reveals meaningful within-year occurrence/intensity differences and supported same-month interannual contrasts, while making the limits imposed by coverage explicit. Task 2 demonstrates that short-term rainfall history supplies useful probability information beyond historical threshold prevalence: the locked tree improves final-test mean Brier by 38.59%, with weaker relative skill for the rarest 5 mm event. The delivered model accepts station, time and threshold within a documented support scope and passes persisted-model/past-only checks. These conclusions are bounded by the retrospective time contract and do not establish real-time or long-term climate performance.

## References and evidence

[1] NEA, Historical Rainfall across Singapore, data.gov.sg collection 2279. https://data.gov.sg/collections/2279/view (accessed 12 October 2026).

[2] Apache Spark 3.5.7, Classification and regression. https://spark.apache.org/docs/3.5.7/ml-classification-regression.html

[3] Apache Spark 3.5.7, ML Pipelines. https://spark.apache.org/docs/3.5.7/ml-pipeline.html

[4] Project E2 protocol and frozen config: archive/history_v1/docs/E2_ROLLING_VALIDATION.md; configs/project.json; C_delivery/configs/C_experiment.json. Primary local evidence includes A annual_cleaning_and_targets.csv, B findings/coverage tables, C development_metrics.csv, selection.json, final_test.json and model_reload_validation.json. A report/receipt evidence is distinguished from the current Mac replay.

## Appendix: 2021 complete development metrics

| Model | mm | Event rate | Brier | Log loss | PR-AUC | ROC-AUC |
|---|---|---|---|---|---|---|
| Baseline | 0 | 0.060931 | 0.057228 | 0.229608 | 0.060931 | 0.500000 |
| Baseline | 0.5 | 0.035763 | 0.034500 | 0.154486 | 0.035763 | 0.500000 |
| Baseline | 1 | 0.025885 | 0.025233 | 0.120534 | 0.025885 | 0.500000 |
| Baseline | 2 | 0.017239 | 0.016950 | 0.087364 | 0.017239 | 0.500000 |
| Baseline | 5 | 0.008877 | 0.008800 | 0.050912 | 0.008877 | 0.500000 |
| LR | 0 | 0.060931 | 0.034720 | 0.139207 | 0.669028 | 0.875574 |
| LR | 0.5 | 0.035763 | 0.019294 | 0.083506 | 0.640883 | 0.894947 |
| LR | 1 | 0.025885 | 0.015335 | 0.068513 | 0.585358 | 0.890219 |
| LR | 2 | 0.017239 | 0.012055 | 0.054929 | 0.507219 | 0.881205 |
| LR | 5 | 0.008877 | 0.007010 | 0.034073 | 0.405241 | 0.878675 |
| Tree | 0 | 0.060931 | 0.031502 | 0.141514 | 0.703433 | 0.807009 |
| Tree | 0.5 | 0.035763 | 0.019297 | 0.086308 | 0.639686 | 0.843876 |
| Tree | 1 | 0.025885 | 0.015246 | 0.069204 | 0.581411 | 0.841533 |
| Tree | 2 | 0.017239 | 0.011711 | 0.055536 | 0.468497 | 0.830913 |
| Tree | 5 | 0.008877 | 0.006618 | 0.036499 | 0.403634 | 0.828123 |

All three candidates use the same supported full evaluation anchors: 6,976,044 per threshold. Approximate AUC uses Spark numBins=1000. The main selection rule remains equal-threshold/equal-year Brier.

## Appendix: 2022 complete development metrics

| Model | mm | Event rate | Brier | Log loss | PR-AUC | ROC-AUC |
|---|---|---|---|---|---|---|
| Baseline | 0 | 0.064804 | 0.060644 | 0.240335 | 0.064804 | 0.500000 |
| Baseline | 0.5 | 0.035889 | 0.034612 | 0.154810 | 0.035889 | 0.500000 |
| Baseline | 1 | 0.025229 | 0.024599 | 0.117891 | 0.025229 | 0.500000 |
| Baseline | 2 | 0.016969 | 0.016684 | 0.086115 | 0.016969 | 0.500000 |
| Baseline | 5 | 0.009109 | 0.009028 | 0.051979 | 0.009109 | 0.500000 |
| LR | 0 | 0.064804 | 0.038477 | 0.153046 | 0.646019 | 0.864880 |
| LR | 0.5 | 0.035889 | 0.020353 | 0.087905 | 0.608708 | 0.881650 |
| LR | 1 | 0.025229 | 0.015746 | 0.070586 | 0.553324 | 0.876966 |
| LR | 2 | 0.016969 | 0.012192 | 0.056048 | 0.487333 | 0.870590 |
| LR | 5 | 0.009109 | 0.007120 | 0.034610 | 0.401769 | 0.874589 |
| Tree | 0 | 0.064804 | 0.034893 | 0.155426 | 0.686436 | 0.798052 |
| Tree | 0.5 | 0.035889 | 0.020272 | 0.090266 | 0.613800 | 0.834824 |
| Tree | 1 | 0.025229 | 0.015371 | 0.070209 | 0.545945 | 0.832217 |
| Tree | 2 | 0.016969 | 0.011511 | 0.055234 | 0.437537 | 0.825002 |
| Tree | 5 | 0.009109 | 0.006821 | 0.037170 | 0.397890 | 0.831761 |

All three candidates use the same supported full evaluation anchors: 7,072,758 per threshold. Approximate AUC uses Spark numBins=1000. The main selection rule remains equal-threshold/equal-year Brier.

## Appendix: 2023 complete development metrics

| Model | mm | Event rate | Brier | Log loss | PR-AUC | ROC-AUC |
|---|---|---|---|---|---|---|
| Baseline | 0 | 0.066713 | 0.062310 | 0.245457 | 0.066713 | 0.500000 |
| Baseline | 0.5 | 0.037479 | 0.036092 | 0.160107 | 0.037479 | 0.500000 |
| Baseline | 1 | 0.026297 | 0.025615 | 0.121837 | 0.026297 | 0.500000 |
| Baseline | 2 | 0.017291 | 0.016996 | 0.087413 | 0.017291 | 0.500000 |
| Baseline | 5 | 0.008702 | 0.008627 | 0.049975 | 0.008702 | 0.500000 |
| LR | 0 | 0.066713 | 0.038800 | 0.152242 | 0.672113 | 0.888477 |
| LR | 0.5 | 0.037479 | 0.020586 | 0.087468 | 0.635994 | 0.910461 |
| LR | 1 | 0.026297 | 0.016073 | 0.070502 | 0.571362 | 0.908028 |
| LR | 2 | 0.017291 | 0.012636 | 0.056382 | 0.481283 | 0.900575 |
| LR | 5 | 0.008702 | 0.007112 | 0.034088 | 0.384725 | 0.899031 |
| Tree | 0 | 0.066713 | 0.035137 | 0.155810 | 0.695372 | 0.803894 |
| Tree | 0.5 | 0.037479 | 0.020765 | 0.091492 | 0.625878 | 0.843163 |
| Tree | 1 | 0.026297 | 0.015974 | 0.071579 | 0.550121 | 0.841306 |
| Tree | 2 | 0.017291 | 0.011994 | 0.056455 | 0.429597 | 0.831717 |
| Tree | 5 | 0.008702 | 0.006670 | 0.036801 | 0.372486 | 0.831313 |

All three candidates use the same supported full evaluation anchors: 6,686,625 per threshold. Approximate AUC uses Spark numBins=1000. The main selection rule remains equal-threshold/equal-year Brier.
